# <img src='./confucius.png' width='50' height='50' style='vertical-align:bottom'/> Confucius Quotes


## About

Quote from Confucius
  
![](gui.png)

## Examples
* "Who is Confucius"
* "Quote from Confucius"
* "When was Confucius born"
* "When did Confucius die"


## Credits
JarbasAl

## Category
**Information**

## Tags
#quotes
